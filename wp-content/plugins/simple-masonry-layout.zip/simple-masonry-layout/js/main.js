new AnimOnScroll( document.getElementById( 'sm-grid-layout' ), {

				minDuration : 0.4,

				maxDuration : 0.7,

				viewportFactor : 0.2

			} );

		